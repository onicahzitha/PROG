/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quetsion1;

/**
 *
 * @author Onicah
 */

import java.util.Scanner;


public class Question1 {
    

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] productNames = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int[][] productSales = new int[3][3];

        for (int i = 0; i < productNames.length; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print(
                    "Enter number of sales for month " +
                    (j + 1) + " for " +
                    productNames[i] + " mattress: "
                );

                productSales[i][j] = input.nextInt();
            }

            System.out.println();
        }

        Product product = new Product(productNames, productSales);

        PrintProduct report = new PrintProduct();

        report.PrintReport(product);

        input.close();
    }
}

