/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.quetsion1;

/**
 *
 * @author Onicah
 */
public interface IProducts {
  

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}
