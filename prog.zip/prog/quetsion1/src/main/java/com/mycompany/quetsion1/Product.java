/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quetsion1;

/**
 *
 * @author Onicah
 */
public class Product implements IProducts {
    





    private String[] productNames;
    private int[][] productSales;

    public Product(String[] productNames, int[][] productSales) {

        this.productNames = productNames;
        this.productSales = productSales;
    }

    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                total += productSales[i][j];
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductSold() {

        int total = GetTotalProductsSold();
        int count = 0;

        for (int i = 0; i < productSales.length; i++) {
            count += productSales[i].length;
        }

        return (double) total / count;
    }

    @Override
    public String GetMostPopularProduct() {

        int highestSales = 0;
        int popularIndex = 0;

        for (int i = 0; i < productSales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < productSales[i].length; j++) {
                productTotal += productSales[i][j];
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
                popularIndex = i;
            }
        }

        return productNames[popularIndex] + "(" + highestSales + ")";
    }
}


