/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Onicah
 */
public class ProductCalculationsTest {
    
    public ProductCalculationsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

 @Test
    public void testGetVat() {

        ProductCalculations product =
                new ProductCalculations(3500);

        double result = product.GetVat();

        assertEquals(525.0, result, 0.01);
    }

    @Test
    public void testGetCommission() {

        ProductCalculations product =
                new ProductCalculations(3500);

        double result = product.GetCommission();

        assertEquals(175.0, result, 0.01);
    }

    @Test
    public void testGetTotal() {

        ProductCalculations product =
                new ProductCalculations(3500);

        double result = product.GetTotal();

        assertEquals(4200.0, result, 0.01);
    }

}
