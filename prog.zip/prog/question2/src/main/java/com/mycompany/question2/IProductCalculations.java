/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.question2;

/**
 *
 * @author Onicah
 */
public interface IProductCalculations {
    

    double GetVat();

    double GetCommission();

    double GetTotal();
}
