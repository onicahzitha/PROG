/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2;

/**
 *
 * @author Onicah
 */
public class Question2 {

   public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {

            new ProductApp();

        });
    }
}
