/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2;

/**
 *
 * @author Onicah
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {
    



    private JTextField txtCustomerName;
    private JTextField txtPrice;

    private JComboBox<String> cmbProduct;

    private JButton btnProcess;

    private JMenuItem menuExit;
    private JMenuItem menuProcess;
    private JMenuItem menuClear;

    public ProductApp() {

        setTitle("Product App");

        setSize(500, 300);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        createMenu();

        createForm();

        setVisible(true);
    }

    private void createMenu() {

        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");

        JMenu toolsMenu = new JMenu("Tools");

        menuExit = new JMenuItem("Exit");

        menuProcess = new JMenuItem("Process");

        menuClear = new JMenuItem("Clear");

        fileMenu.add(menuExit);

        toolsMenu.add(menuProcess);

        toolsMenu.add(menuClear);

        menuBar.add(fileMenu);

        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        menuExit.addActionListener(e -> {
            System.exit(0);
        });

        menuProcess.addActionListener(e -> {
            processSale();
        });

        menuClear.addActionListener(e -> {
            clearForm();
        });
    }

    private void createForm() {

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 15));

        panel.setBorder(BorderFactory.createEmptyBorder(
                20, 20, 20, 20));

        JLabel lblCustomerName = new JLabel("Customer Name:");

        txtCustomerName = new JTextField();

        JLabel lblProduct = new JLabel("Select Product:");

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        cmbProduct = new JComboBox<>(products);

        JLabel lblPrice = new JLabel("Enter Price:");

        txtPrice = new JTextField();

        btnProcess = new JButton("PROCESS");

        panel.add(lblCustomerName);
        panel.add(txtCustomerName);

        panel.add(lblProduct);
        panel.add(cmbProduct);

        panel.add(lblPrice);
        panel.add(txtPrice);

        panel.add(new JLabel(""));
        panel.add(btnProcess);

        add(panel);

        btnProcess.addActionListener(e -> {
            processSale();
        });
    }

    private void processSale() {

        try {

            String customerName = txtCustomerName.getText().trim();

            String productName =
                    cmbProduct.getSelectedItem().toString();

            if (customerName.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter the customer name."
                );

                return;
            }

            double price = Double.parseDouble(
                    txtPrice.getText().trim()
            );

            if (price <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter a valid price."
                );

                return;
            }

            ProductCalculations calculations =
                    new ProductCalculations(price);

            double vat = calculations.GetVat();

            double commission = calculations.GetCommission();

            double total = calculations.GetTotal();

            String message =
                    "Customer Name: " + customerName +
                    "\nProduct: " + productName +
                    "\nVAT: R " + vat +
                    "\nCOMMISSION: R " + commission +
                    "\nTOTAL: R " + total;

            JOptionPane.showMessageDialog(
                    this,
                    message,
                    "Message",
                    JOptionPane.INFORMATION_MESSAGE
            );

            saveToFile(
                    customerName,
                    productName,
                    vat,
                    commission,
                    total
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid numeric price."
            );

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving data to file."
            );
        }
    }

    private void saveToFile(
            String customerName,
            String productName,
            double vat,
            double commission,
            double total) throws IOException {

        try (PrintWriter writer = new PrintWriter(
                new FileWriter("data.txt", true))) {

            writer.println("DATA LOG");

            writer.println("********************************");

            writer.println("Customer Name: " + customerName);

            writer.println("Product: " + productName);

            writer.println("VAT: R " + vat);

            writer.println("COMMISSION: R " + commission);

            writer.println("TOTAL: R " + total);

            writer.println("********************************");

            writer.println();
        }
    }

    private void clearForm() {

        txtCustomerName.setText("");

        txtPrice.setText("");

        cmbProduct.setSelectedIndex(0);
    }
}

